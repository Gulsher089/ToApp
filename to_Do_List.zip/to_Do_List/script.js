const taskInput = document.getElementById("task-input");
const addBtn = document.getElementById("add-btn");
const taskList = document.getElementById("task-list");
const clearBtn = document.getElementById("clear-all");
const filterButtons = document.querySelectorAll(".filter-btn");

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks(filter = "all") {
  taskList.innerHTML = "";
  tasks.forEach((task, index) => {
    if (
      filter === "all" ||
      (filter === "completed" && task.completed) ||
      (filter === "uncompleted" && !task.completed)
    ) {
      const li = document.createElement("li");
      li.classList.toggle("completed", task.completed);

      li.innerHTML = `
        ${task.text}
        <div class="task-buttons">
          <button onclick="toggleTask(${index})">✔</button>
          <button onclick="editTask(${index})">✏</button>
          <button onclick="deleteTask(${index})">🗑</button>
        </div>
      `;
      taskList.appendChild(li);
    }
  });
}

function addTask() {
  const text = taskInput.value.trim();
  if (text === "") {
    showMessage("Please enter some text!");
    return;
  }
  tasks.push({ text, completed: false });
  taskInput.value = "";
  saveTasks();
  renderTasks();
}
function showMessage(msg) {
  const messageBox = document.createElement("div");
  messageBox.textContent = msg;
  messageBox.className = "message";
  document.body.appendChild(messageBox);

  setTimeout(() => {
    messageBox.remove();
  }, 2000);
}



function toggleTask(index) {
  tasks[index].completed = !tasks[index].completed;
  saveTasks();
  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  saveTasks();
  renderTasks();
}

function editTask(index) {
  const newText = prompt("Edit your task:", tasks[index].text);
  if (newText) {
    tasks[index].text = newText;
    saveTasks();
    renderTasks();
  }
}

addBtn.addEventListener("click", addTask);
clearBtn.addEventListener("click", () => {
  tasks = [];
  saveTasks();
  renderTasks();
});

filterButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelector(".filter-btn.active").classList.remove("active");
    btn.classList.add("active");
    renderTasks(btn.dataset.filter);
  });
});

renderTasks();
